<?php
// Where will you get the forms' results?
define("CONTACT_FORM", 'bikers.wearhouse@gmail.com');
?>